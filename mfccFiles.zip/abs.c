/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: abs.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 25-Mar-2018 19:52:49
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "mfcc.h"
#include "abs.h"

/* Function Declarations */
static double rt_hypotd_snf(double u0, double u1);

/* Function Definitions */

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_hypotd_snf(double u0, double u1)
{
  double y;
  double a;
  double b;
  a = fabs(u0);
  b = fabs(u1);
  if (a < b) {
    a /= b;
    y = b * sqrt(a * a + 1.0);
  } else if (a > b) {
    b /= a;
    y = a * sqrt(b * b + 1.0);
  } else if (rtIsNaN(b)) {
    y = b;
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

/*
 * Arguments    : const double x[4000]
 *                double y[4000]
 * Return Type  : void
 */
void b_abs(const double x[4000], double y[4000])
{
  int k;
  for (k = 0; k < 4000; k++) {
    y[k] = fabs(x[k]);
  }
}

/*
 * Arguments    : const creal_T x[12288]
 *                double y[12288]
 * Return Type  : void
 */
void c_abs(const creal_T x[12288], double y[12288])
{
  int k;
  for (k = 0; k < 12288; k++) {
    y[k] = rt_hypotd_snf(x[k].re, x[k].im);
  }
}

/*
 * File trailer for abs.c
 *
 * [EOF]
 */
