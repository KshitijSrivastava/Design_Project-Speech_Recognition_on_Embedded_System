/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: log.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 25-Mar-2018 19:52:49
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "mfcc.h"
#include "log.h"

/* Function Definitions */

/*
 * Arguments    : double x[600]
 * Return Type  : void
 */
void b_log(double x[600])
{
  int k;
  for (k = 0; k < 600; k++) {
    x[k] = log(x[k]);
  }
}

/*
 * File trailer for log.c
 *
 * [EOF]
 */
