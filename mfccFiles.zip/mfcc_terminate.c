/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: mfcc_terminate.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 25-Mar-2018 19:52:49
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "mfcc.h"
#include "mfcc_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void mfcc_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for mfcc_terminate.c
 *
 * [EOF]
 */
