/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_ZCR_info.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:14:29
 */

/* Include Files */
#include "_coder_ZCR_info.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[11] = {
    "789ced58cb6fe3441877d91296032c420269e140c401812ac5499bb6ee9e368fe6d126691c27694285c08f49ea666c2763a7496f3d2271006edc39ee09fe02e0"
    "8ee00027aefc099c119e3c9a74d6bb53397163e48c34727e71bea7bf5fbef1c76ce48b8cbddeb4f7efdb0c13b2af0fedfd0a335eaf4ef086bd1f4daee3ef3799",
    "3726f86b7bcb866e81a135bea98b1a60a64b3134551775ab7ad5050c02a6012f8132bad35221a8aa1a28187320a7da40cbccddba01f816fe9c3a077247e86b0c"
    "3a376fcc30701e8ce21932b378361de2c9ccc5f3d6049f1d7e967ac2d64c804cf664a003c4a60db9af01dd32d962a25a4824d93430d5b61e2e23e302c8165b4f",
    "a4c309d836906a9d6b26fb69aa12d1c6f6a314fb9bb7ec6f32582d96e3287221c2efd028cb7d0982bbc59d23e4313ecb171aa3d0edb0da48d4c238d1372157b6"
    "a3b13d89b50c034ac690051a64a12ab19a68415162016cf575167b1fd148ff430ef637e6ecbf3ef9de5e3fd73efa33b180fc68f9413e47c9ffbb44fe31e6abb5",
    "c368747075d1931142461c084599cb8cf57d3ca76fc3411f337775f3fb55d74b9962ff03c23ec6b2a1001451ed3f1da48b30a29ac9be0aadbc5eb2b98a54f9b9"
    "e7e886475f52e41b847cc34d5ef0de1a45c36e4dc361c97016e2552efceb1f81e5551aaa31914bb73371e9a0cf2927bab6972ce7d6bcc276df23ec634cf0ca94",
    "4528a208d6398beb657d6dbae6f54ee5687caa12725537f970e4d3d6388e496ea6feb8acc7d0bfbf04b74ff5ea7cbc8100d4b5e4ce0e42475108e07e40fad417"
    "14fb9f10f63126f82476bbf04a181563a6afcb966ae879bd0c45797a5ec6769e52ec3c22ec60dc9a68fbfc5cd415bb81613ddf51f448841ec94dbe1cf9f6e230",
    "c7ec5ba87ed13f3bc1e55f5cafe9bb6a7c103545c19006a0dae1c474fa7ef8e7f77af2aadf797d8e5cf73dfff3cecf7d6fd5738c07b7ec3f6044c95c0a6f6871"
    "6709798c17eff7b6f776e0eeebecfaa720cf317a92a4b4e25de9a45a16106fc4b259588827fdc113afeb653dc758cf31bce2959fe718abe6d563c23ec6cee73a",
    "dc9966717935c7100839c14d3e5e7a9e1be766ea8fcb3ef5ed5f4f82dba72e76b37c5be1ebf9834c29765097f8dd76ab9c0a069f1a14fb1f12f631a6cf3166f1"
    "3da5e8bfebfce21b8a9e3342cf999b3cddf57d7371be7d1594b9c53bccede78271936fe562db592e99ebed8bfd62a963edb725e67ef8e6d73af2aaaf797d5e5c",
    "f7377ff1edffd6dfbc9e57d0eaff21611f630d29eaa5aa8065f0e79a227f44c863bc487f37ba263bf53fd29d3d0797bcf9edc7bf57ca9b1f4e1f2fc7be1bde0c"
    "76eae8aa54aac91d2391406da19fe494d37be2cd35c5df55d48d931faf117e603c51b394fe43cb439e90cf2f210fd3346873cfc3257f9ebdcf07a3ef389df3b8",
    "01dfaa35e27bfbb94b583948735cc1a8c98c3ff8735f75b39e03aee7805ef5a755ce01af29fefa855f61c20f8c1dde9bc0b09b32b4ae68a9364396c12fda7b66"
    "93906fbac98f23bf9e0b67097d8c79b6ac73d8aae5ddf04c1a364b9596d8a9f3c5e3d25105584254380918cf68797b9bf003638267b6d6993eafcf85c784fcb1",
    "9bbc38f2cb0e63f179c4f74139173af1a958b3a2cdfc6942d76b15b56cf2a5b659ed1d7acfa7ff00038203bb",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 13024U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[4] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 4, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name", mxCreateString("ZCR"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", mxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", mxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", mxCreateString("9.1.0.441655 (R2016b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_ZCR_info.c
 *
 * [EOF]
 */
