/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ZCR.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:14:29
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "ZCR.h"

/* Function Definitions */

/*
 * Function to determine what the zero crossing rate is within a window of audio.
 *
 *  This function helps determine if the selected frame of samples contains either
 *  a voiced or unvoiced signal. This is determined by calculating the Zero
 *  Cross Rate (ZCR) of the samples. The Zero crossing rate is the rate at which the signal
 *  crosses over the zero axis. It is a general rule that
 *  a voiced signal contains a low ZCR while the inverse is
 *  true for unvoiced speech. This algorithm detrmines the value of this
 *  variable.
 * Arguments    : const double Speech[400]
 *                double window
 * Return Type  : double
 */
double ZCR(const double Speech[400], double window)
{
  double z;
  int i;
  double b_Speech;
  double c_Speech;

  /*        Inputs:  */
  /*                Speech = Speech segment */
  /*                Window = Window size */
  z = 0.0;

  /*  Initializing zcr variable */
  for (i = 0; i < (int)(window + -1.0); i++) {
    /*  For loop to create summation */
    /* Intermediate ZCR calculation */
    if (Speech[i + 1] < 0.0) {
      b_Speech = -1.0;
    } else if (Speech[i + 1] > 0.0) {
      b_Speech = 1.0;
    } else if (Speech[i + 1] == 0.0) {
      b_Speech = 0.0;
    } else {
      b_Speech = Speech[i + 1];
    }

    if (Speech[(int)((2.0 + (double)i) - 1.0) - 1] < 0.0) {
      c_Speech = -1.0;
    } else if (Speech[(int)((2.0 + (double)i) - 1.0) - 1] > 0.0) {
      c_Speech = 1.0;
    } else if (Speech[(int)((2.0 + (double)i) - 1.0) - 1] == 0.0) {
      c_Speech = 0.0;
    } else {
      c_Speech = Speech[(int)((2.0 + (double)i) - 1.0) - 1];
    }

    z += fabs(b_Speech - c_Speech);

    /*  Adding calculation to sum */
  }

  z /= 2.0 * window;

  /*  Divide by window size to normailze variable */
  return z;
}

/*
 * File trailer for ZCR.c
 *
 * [EOF]
 */
