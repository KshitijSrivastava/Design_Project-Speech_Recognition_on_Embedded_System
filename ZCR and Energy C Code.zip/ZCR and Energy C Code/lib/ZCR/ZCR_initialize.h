/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ZCR_initialize.h
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:14:29
 */

#ifndef ZCR_INITIALIZE_H
#define ZCR_INITIALIZE_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ZCR_types.h"

/* Function Declarations */
extern void ZCR_initialize(void);

#endif

/*
 * File trailer for ZCR_initialize.h
 *
 * [EOF]
 */
