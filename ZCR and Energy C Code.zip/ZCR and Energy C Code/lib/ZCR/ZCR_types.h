/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ZCR_types.h
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:14:29
 */

#ifndef ZCR_TYPES_H
#define ZCR_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for ZCR_types.h
 *
 * [EOF]
 */
