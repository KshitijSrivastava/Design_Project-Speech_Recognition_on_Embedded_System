/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ZCR_terminate.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:14:29
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "ZCR.h"
#include "ZCR_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void ZCR_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for ZCR_terminate.c
 *
 * [EOF]
 */
