/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: energy.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:48:34
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "energy.h"
#include "energy_emxutil.h"

/* Function Definitions */

/*
 * This function calculates the normalized short term energy of a sample frame
 *
 *    This function calculates the energy of the windowed speech signal. This
 *    is primarily used for voice activity detection. The general rule is
 *    that for a voiced audio segment the energy of the signal is high while
 *    for unvoiced segments the energy of the window is low.
 * Arguments    : const double speech[400]
 *                double window
 * Return Type  : double
 */
double energy(const double speech[400], double window)
{
  double e;
  emxArray_real_T *y;
  int k;
  int loop_ub;
  emxArray_real_T *b_y;
  emxArray_real_T *x;
  double a[400];
  double c_y[400];

  /*  */
  /*            Inputs: */
  /*                 Speech: Input windowed speech signal     */
  emxInit_real_T(&y, 2);
  if (rtIsNaN(window)) {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)y, k, (int)sizeof(double));
    y->data[0] = rtNaN;
  } else if (window < 1.0) {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 0;
    emxEnsureCapacity((emxArray__common *)y, k, (int)sizeof(double));
  } else if (rtIsInf(window) && (1.0 == window)) {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)y, k, (int)sizeof(double));
    y->data[0] = rtNaN;
  } else {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)floor(window - 1.0) + 1;
    emxEnsureCapacity((emxArray__common *)y, k, (int)sizeof(double));
    loop_ub = (int)floor(window - 1.0);
    for (k = 0; k <= loop_ub; k++) {
      y->data[y->size[0] * k] = 1.0 + (double)k;
    }
  }

  emxInit_real_T1(&b_y, 1);
  k = b_y->size[0];
  b_y->size[0] = y->size[1];
  emxEnsureCapacity((emxArray__common *)b_y, k, (int)sizeof(double));
  loop_ub = y->size[1];
  for (k = 0; k < loop_ub; k++) {
    b_y->data[k] = 6.2831853071795862 * y->data[y->size[0] * k] / (window + 1.0);
  }

  emxFree_real_T(&y);
  emxInit_real_T1(&x, 1);
  k = x->size[0];
  x->size[0] = b_y->size[0];
  emxEnsureCapacity((emxArray__common *)x, k, (int)sizeof(double));
  loop_ub = b_y->size[0];
  for (k = 0; k < loop_ub; k++) {
    x->data[k] = b_y->data[k];
  }

  for (k = 0; k + 1 <= b_y->size[0]; k++) {
    x->data[k] = cos(x->data[k]);
  }

  emxFree_real_T(&b_y);
  for (k = 0; k < 400; k++) {
    a[k] = speech[k] * (0.54 - 0.46 * x->data[k]);
  }

  emxFree_real_T(&x);
  for (k = 0; k < 400; k++) {
    c_y[k] = a[k] * a[k];
  }

  e = c_y[0];
  for (k = 0; k < 399; k++) {
    e += c_y[k + 1];
  }

  /*  Energy calculation */
  return e;
}

/*
 * File trailer for energy.c
 *
 * [EOF]
 */
