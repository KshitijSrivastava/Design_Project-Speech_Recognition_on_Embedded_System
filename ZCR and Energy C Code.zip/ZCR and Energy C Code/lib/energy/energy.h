/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: energy.h
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:48:34
 */

#ifndef ENERGY_H
#define ENERGY_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "energy_types.h"

/* Function Declarations */
extern double energy(const double speech[400], double window);

#endif

/*
 * File trailer for energy.h
 *
 * [EOF]
 */
