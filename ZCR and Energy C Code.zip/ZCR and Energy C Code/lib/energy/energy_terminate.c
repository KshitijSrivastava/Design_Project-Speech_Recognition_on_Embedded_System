/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: energy_terminate.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:48:34
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "energy.h"
#include "energy_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void energy_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for energy_terminate.c
 *
 * [EOF]
 */
