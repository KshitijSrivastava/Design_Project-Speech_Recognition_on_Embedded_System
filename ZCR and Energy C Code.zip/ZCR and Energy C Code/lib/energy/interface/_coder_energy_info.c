/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_energy_info.c
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:48:34
 */

/* Include Files */
#include "_coder_energy_info.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[27] = {
    "789ced5dcd8f234715ef25bb4bf610081f818424b00b110a04ad3d33fe9a1cd0da6e7fcdf873da1e7bbc09de76bbdaae717fd8ddedb13d279f101287704239c0"
    "894b481421e002478438222201127f00072e481ce04e973ddef1567ab6bdfde5f6748f64cdbcf1bcaaf7debc5fbf57af5e95891bb902a17e7d4e7d7df20941dc",
    "56bf3fafbe3e432cbe6e5dd037d4d7f72fbe2f7e7f9378e1827e4f7d31a2a08089b27853a079402cbf3a220f055a50aad3012024208bdc19e8ccdf612107aa90"
    "07797185c84295e0d32b6f3d26d05be8e7640f307d6ac413524f7e3c0dc1ad12737d66c4a53e3735f4c9ade8f3e205fd30f56ef2ed404d06921c288d05200548",
    "9119f14050e440215ecdc7130112c8b02bdc2d4be2296094c0719cbc1be7baa204951e2f0780cad39ddee757e488e9c8710b93e3d6dc9e9c28acc97f1be3bf3d"
    "b7faa8cd8105ff44873f83f123fa612edf989b4255b32bd1fc5d64f8c72638da0dee44da014514b9b63809009e0b70b01de06985a3db01712007e6f2ab56c0e5",
    "bfad31ff8d95f9ef5cfc5efdef655fffd9dfe3c6f9b5edbf09feac8efdbf82d91fd1238aad4d8b99314c364a8328ac140e6077905c8cf7e6ca783734c62356be"
    "1bf9fb4dfb4b5967fe6f60f3239a113b40ba0fd5879024d0dc7d2827469053724251c5ae04194b70f4231dfe06c6df306217f47a6bae4de0ada53a015c9dfbbc",
    "09bfccdefdf3df3c8b2b92833b748ceca643edfd51ac5312f848a29cf506aefc38e4c7213f0ed98b1728abb92e610d5e663afc9af9ab09fd01a7fe10986b7065"
    "fefa0c7ef7abfa2bdec50dcbe72289fd484ce9659be120ddcbc628a994760637331d799df21b3f8ff3f3383f8fb33e2ee9d9eb8bd8fc88c670b5085217fa0475",
    "c6bbf9c4783709a6474beb3c670e31390e8dd8411347974f1a13fef7da6ff3dec0cf4bc493ff0744efefcb1de69012e307bb7ba17a33a174fb9106e10dfc18cb"
    "eba0c012db9dd7a91af879dd0abf91b8739ed913f37bcd1c231c26760b85496d3f1faa64ae775e87fb8d9fd7f9799d9fd7b9232eb19c284ac4b6c625762404e6",
    "1a581197fe50fbb677e3526c182d55871c19ee277ad54a86528624c95cdb7a83b6dff871c98f4bd7312ecd74e4750bbe5ec5e44034862f99a1395ababf8c5afa"
    "f587e5d7eab84b3e3d5cd530be9a11bb68e2eaad851e2b3632b1bff4a197d753ed5ea4dc1038a543897c6a2464f7daa9c4c1b55d4f69e3ea918e1cdfc1e44034",
    "862b7a30e0a6d4dc29d3238151a028e48432473360659e073af37c1e9b07d1ecc568ad1e2d74d48086c6795f679c36364edb88dd347177b59a4b839af063e9bf"
    "7bdec56148a80961181a07659a12db6350edc768927406876ef727bbe29edd79a51fffdc8fbbad8b7f36f4c7ead9ed0b981c8856ddb2c52b900772ab07b80190",
    "56c6b32b9fa4303e449badff7c4a0fd3fb5ab3de9f7eef5d3c35bb876c1c9ea740b94ba6f62b7ce52028671cc2935e1ca33179116d83ffdc63449e57333606b5"
    "c9cb2bf2f9f511bf3e6217eeb6ae3eb281731ecf6372209a973af00c768013f5fb038c1fd1669f3f4bf9ef0fb4edf00c71eb2fbff9e746e3d6afadca438de067",
    "bc772c4d8bc51ad317e371a94b8d12b14edda13edb998ebc9bf01b2d393e8bc981e88b61b672ff0bd9616906f3fb5fb38f5ead7823efd3ea678a8d2b6cad118a"
    "44b367dcd13e198be5c51a43b8033f4ef98d9fdff9f99d9fdf6d0e5f77313910ad510704934152e407b40255845881af9fe8f09f60fc2746eca389af4fa96345",
    "1fc7479eae074e4e8a472cdd3fae140e8b074740a18254c96338d3b3db1afdedeaa897e3d99d17dad7e7aeaa61be1ef80bafe4855a782ad494e049ae1e1784da"
    "112ccb956257ae0e532ec6930d7509bdf31dcf3d21c7732a96644b70e3743fe5627f5d95ded4795f6ff7110eaa93d368492947a225ba4a9d56a5cc941112d7b3",
    "ff16f717bdfcee156c7e446beff322045deae5eafda8a7eeef2e6cb394c7a03f467efa4befe22926e565bac2144eeaed93463b918884d82ef0089e1ee9cceff7"
    "35f97d4d76e3cfef6b32ded7f43a261fa2317c8e6450a625569492a2202bc47af9e655e789f5e2dd3126cfb165f67a520d642313ebadd81fbfeb5dbc29ed0e49",
    "33b14425913ce74b53490a827ec4a1f596dbfc47cf7e2f63f220fa2a7cd999475630be8af576b1a22ef846ff3defe22a3a542ae3542f244fab612a1e2f0fd302"
    "acbaa4afc9ed71eceb987c88467d53ea342dd53739511cb4c43320b19c385e744d995bb7e9d5e31f617c8f8cd86b35ef5e98ef29fa98d9f79a79fabcbf989c0c",
    "2b6ca119ef492229a5f24a7d5c683ad497f13b1d797f88c98b68bbfde8ded3ffe07133ae913c10ca2c5ce7fff4554c6f44e3fbd842074c7282b2d63a388d8d97"
    "366a47164e406720aa5204902ee6f248e2632fe3aebc5b0d9e97a74263323cdd9b1e644fab54bb997547ddc46e7f79a033ff0bd8fc8886b2b0687150d035dbe6",
    "d661331dbe12367fc912fd57e43757bff7346e327bfd2935ec422e594df68f86896eb55f4b3954efd8f6786564bf4b1d9aa727f6e2cdeafecb8b7b7de6925b50"
    "5ff4747ec84d224d103c2d056b3011ac8ecf77e810e7545f9457f106856dc51b147cbc5df21bc15b3857e80ffa453051b205aa5bce1c963341cea1fdb46daf83",
    "18ddbfb6bbffd7dfc7763fee36b98f3dd391d72de7bb6e6172207a208e8155f7b339bd9f8ffa33e7f29bfbfc8437fe53f62e6eda9d93683d38acc4f633242d1e"
    "64a2e769aee2d07ed8a6fdc53f8fe29f47b10b576e3e8f52c6e445b445b8bac772cafc478beae48bfc28d5b504578ed8e5ca7328480d53787af3df25efc6a952",
    "26931c864a94ccedd4ebc348a72dc30a74c9f963a7fce6818e1cebd6ddedc6915f7f772f8e36597f9fe9c8bb89e7efbaf760a0fd2f35dcf59cc08f65f53d6cff"
    "0ec96f417dcf33f8d13ac77f3604a9c11923ef37c67ba25896a99dbd9326e18efe41fbd60597f8b9c7424956167d107e5f93dfd764579cda645f93db7066b44f",
    "c9ee7a5e1ae34f1bb183df977425bf11dc6cb22f69a623af537587868e1cdfc4e440b4feb9ae4b3d1fe88cbfee792ebd78f5101be7a1117badbb5f67fe1cff8f"
    "bd728e4b2b2f3ca9b0d99ddd4c2c911d46e951a1d857a2dd36e10ceedcea477af9e19af75283c920ce7122f3785cbbebeb558cbf6a99bd56d55918ca84bf7afa",
    "1e1a1865a221be16195095708d94f7dac7c2907668dfca6dfe6341bc5b1db82826176bb1e5f866f1b6b9e793865ae6e3dc8bd39bdec09d66fd235b0a473a4ab1"
    "ce8c1364f4309dc8a54e7a843be2dc0f3079116d07eeee81e188e664780ed68b737e1dc4af836c631d645bf34aff5e004338f3ef05d8d0bd00db8a333faef971",
    "ed3ac6b526262fa2adaa532e2afc2dd58568a5b56cbe5dd38e7ebfd433f9a7df2fb5a17e293d7cbd8bc98b68abf7015a1d91a7a1d00292b4f6e78fdfc2e44234"
    "94055a5893df2c9eacbebff8e25c17d2c08afb6d3c1daf583e1749ec47624a2fdb0c07e95e364649a5b48fa767c5d3f21326b7134fda9f8f6bd01f3d7d8f6f6c",
    "182d55871c19ee277ad54a86528624c93884a7998ebc6ee98fff322607a2b17c6f094753f50b3d7b1430390a46eca199e7cdc537fbf9acff03c0bb381a8552b5"
    "c6eee87022177b72a2704a45e4b0d7ce3deaf93d7e7fbc3cfa74fff836c49f0eadd02802a9f25bf1795c2f3dec7803375afb58050a761ac3e684cd9fcb5d7652",
    "38cdf58421e162dcd8e0377a767b199303d158fc1168a90b05a6d7b7b3aef70ec6f7ceb3da4356031de80416d1e72206e1a1e8b12666fb32665f7afbc8bbe71e"
    "a793716e9f4eb3dd709029a544ea343d8a8e5d524777831ff9eb247f9d745dd6499bc86fb4e4d0fadc55758c81247636b2af5b366b808104cf6805042e9430b9",
    "affb1aed913c4f0b3fbd6ca83008a73be132154b86ced9660f9c851d3aefe836ffd1dbcff5efbbf0efbb308ab34dde77e1369c19b19fcacf00596e5d0cd582c2"
    "60a4c8e6ea7aefebf0014c0e60b55db495325beffbda07d0bbf1ec7018ef1d77c9645d884eda9372f7ec3c3f541c5a5fb9dd9ff4ece9d733fc7ac636d533dc8e",
    "37bd7327dfc2e44334863706f5ad164581824297038a289050fb7c861de74e4ce3f0cabc524b2dd338fcd02bfd175af5fac6285ada4f67e87caa1ece66f97a2a"
    "b87330207c1cae634fbf6ff099fcd4ef1bdc50dfa0dbd67146ea8e509e1f0e7304478718ff21614dbfe05c03f3e724effceb7b7ff52c8e48f2e4e0e4ac1a6e67",
    "e2a9142423d15ea39673a8ee38d391d729bf79a023c78b981cf3d889ce5b2c466a31a2049cc803afea9f34fc5c591864f954c1553259ff20eefcfc03efc62708"
    "4b09b2b0971f88cdf6c10e737ac48e06c72eef6bb7db8ff4ece8d73dfcbac736d53ddc96071a5b5ff16d2880d6196014516a010ecc7b1cd78a8bebde1fa5b72e",
    "65b17158abed74859226ef6f8b89fff0467cd3aa731c373bcd703848ed363a076279479ea6935c9d70479d63d3fee49f47f6cf23db15ef36751ef9ffa2cded9c",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 53472U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[4] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 4, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name", mxCreateString("energy"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", mxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", mxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", mxCreateString("9.1.0.441655 (R2016b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_energy_info.c
 *
 * [EOF]
 */
