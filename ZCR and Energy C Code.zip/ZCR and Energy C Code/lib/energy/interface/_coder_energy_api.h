/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_energy_api.h
 *
 * MATLAB Coder version            : 3.2
 * C/C++ source code generated on  : 13-Feb-2018 20:48:34
 */

#ifndef _CODER_ENERGY_API_H
#define _CODER_ENERGY_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_energy_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern real_T energy(real_T speech[400], real_T window);
extern void energy_api(const mxArray *prhs[2], const mxArray *plhs[1]);
extern void energy_atexit(void);
extern void energy_initialize(void);
extern void energy_terminate(void);
extern void energy_xil_terminate(void);

#endif

/*
 * File trailer for _coder_energy_api.h
 *
 * [EOF]
 */
